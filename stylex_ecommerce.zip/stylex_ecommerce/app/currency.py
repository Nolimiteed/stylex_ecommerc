import os
from decimal import Decimal


class INRToUSDConverter:
    """Offline converter for local demo use."""

    def __init__(self, api_key=None):
        self.exchange_rate = Decimal(os.getenv("INR_TO_USD_RATE", "0.012"))

    def convert_inr_to_usd(self, amount_inr):
        return round(Decimal(amount_inr) * self.exchange_rate, 2)
